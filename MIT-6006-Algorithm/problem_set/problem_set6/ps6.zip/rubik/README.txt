+---------------------------------------+
| Fall 2011 Problem Set 6: Rubik's Cube |
+---------------------------------------+

Package contents:

rubik.py:         Library with Rubik's cube abstraction.
solver.py:        To be filled in and submitted online. Finds the shortest path
                  between two positions.

test_solver.py:   Unit tests for solver.py
visualizer/:      Contains the GUI for visualizing your answer. See its README.
