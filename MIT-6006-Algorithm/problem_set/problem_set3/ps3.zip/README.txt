Please submit the solutions to this problem using Gradetacular, at
http://alg.csail.mit.edu

The site will be open for submissions by Monday, October 3 2011.
